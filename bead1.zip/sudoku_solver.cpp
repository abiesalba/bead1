#include <fstream>
#include <vector>
#include <future> // ASYNC, FUTURE
#include <iostream>

//Helper class for next and prev functions:
class Index{
private:
	int row_ind;
	int col_ind;
	bool is_valid;
public:
	int getRowInd(){return row_ind;}
	int getColInd(){return col_ind;}
	bool getIsValid(){return is_valid;}

	void setRowInd(int new_ind){row_ind = new_ind;}
	void setColInd(int new_ind){col_ind = new_ind;}
	void setIsValid(bool new_val){is_valid = new_val;}

	Index(int row, int col, bool valid): row_ind(row), col_ind(col), is_valid(valid){}
	Index(){}
};

//Inplements a sudoku:
class Sudoku{

private:
    unsigned int _size; //sudoku's size
    std::vector<std::vector<unsigned int>> _matrix; //contains sudoku's matrix
	std::vector<std::vector<unsigned int>> _solution; //contains the solution if solveable

public:
	//Getters:
    unsigned int getSize(){ return _size;}
    std::vector<std::vector<unsigned int>> getMatrix(){return _matrix;}
	std::vector<std::vector<unsigned int>> getSolutionMatrix(){return _solution;}

	//Setters:
	void initializeSolutionMatrix(int size){
		this->_solution.resize(size);
		for(int i = 0; i < size; ++i){
			for(int j = 0; j < size; ++j){
				this->_solution[i].push_back(1);
			}
		}
	}
	void setSolutionMatrix(int i, int j, unsigned int value){_solution[i][j] = value;}

	//Constructors:
	Sudoku(unsigned int sudoku_size, std::vector<std::vector<unsigned int>> sudoku_matrix)
		: _size(sudoku_size), _matrix(sudoku_matrix){}
	Sudoku(){}

	//Prints the sudoku on the screen:
	void printSudoku(){
		//Print the size of the sudoku:
		std::cout<< this->getSize() <<std::endl;
		//Print the matrix of the sudoku:
		for(int i = 0; i < this->getSize(); ++i){
			for(int j = 0; j < this->getSize(); ++j){
				std::cout<< this->getMatrix()[i][j] << " ";
			}
			std::cout<<"\n";
		}
	}

	//Prints the solved sudoku on the screen:
	void printSolutionSudoku(){
		for(int i = 0; i < this->_solution.size(); ++i){
			for(int j = 0; j < this->_solution.size(); ++j){
				std::cout<< _solution[i][j] << " ";
			}
			std::cout<<"\n";
		}
	}

//---------Functions to help solving the sudoku---------------

	//Find out if a sudoku is valid
	bool isValid(){
		for(int i = 0; i < this->getSize(); ++i){
			for(int j = 0; j < this->getSize(); ++j){
				unsigned int actual = this->getMatrix()[i][j];
				if(actual != 0){
					for(int col = j+1; col < this->getSize(); ++col){
						if(this->getMatrix()[i][col] == actual)	return false;
					}
					for(int row = i+1; row < this->getSize(); ++row){
						if(this->getMatrix()[row][j] == actual) return false;
					}
				}
			}
		}
		return true;
	}

	//Returns the next elemnt's index and true if it's exists and false if not:
	Index getNext(int row_ind, int col_ind){
	
		if(col_ind < this->getSize()-1){
			return Index(row_ind, ++col_ind, true);
		}else if(row_ind < this->getSize()-1){
			return Index(++row_ind, 0, true);
		}else{
			return Index(row_ind, col_ind, false);
		}
	}

	//Returns the previous elemnt's index and true if it's exists and false if not:
	Index getPrev(int row_ind, int col_ind){

		if(col_ind > 0){
			return Index(row_ind, col_ind-1, true);
		}else if(row_ind > 0){
			return Index(row_ind-1, this->getSize()-1, true);
		}else{
			return Index(row_ind, col_ind, false);
		}
	}

	//Find out if a num is correct solution of a cell:
	bool isCorrectSolution(int row_ind, int col_ind, int sol_num){

		//Check in the matrix:
		for(int i = 0; i < this->getSize(); ++i){
			if(i != row_ind && this->getMatrix()[i][col_ind] == sol_num){
				return false;
			}
		}
		for(int i = 0; i < this->getSize(); ++i){
			if(i != col_ind && this->getMatrix()[row_ind][i] == sol_num){
				return false;
			}
		}

		//Check the solution matrix:
		for(int i = 0; i < col_ind; ++i){
			if(this->getSolutionMatrix()[row_ind][i] == sol_num){
				return false;
			}
		}
		for(int i = 0; i < row_ind; ++i){
			if(this->getSolutionMatrix()[i][col_ind] == sol_num){
				return false;
			}
		}

		return true;
	}

	//find the next correct num which >= num in to a cell and returns it if exist, returns 0 if not:
	unsigned int findNextCorrectSolution(int row_ind, int col_ind, unsigned int num){
		while(!this->isCorrectSolution(row_ind, col_ind, num) && num <= this->getSize()){
			++num;
		}
		if( num <= this->getSize()){
			return num;
		}else{
			return 0;
		}
	}

	//Recursive function of solveing - returns true if solved the sudoku, false otherwise:
	bool solveSudoku(int row_ind, int col_ind){
		if(this->getMatrix()[row_ind][col_ind] != 0){
			this->setSolutionMatrix(row_ind, col_ind, this->getMatrix()[row_ind][col_ind]);
			Index act = this->getNext(row_ind, col_ind);
			if(act.getIsValid()){
				this->solveSudoku(act.getRowInd(), act.getColInd());
			}else{
				return true;
			}
		}else{
			unsigned int act_sol = this->findNextCorrectSolution(row_ind, col_ind, this->getSolutionMatrix()[row_ind][col_ind]);
			//std::cout<< act_sol <<std::endl;
			if(act_sol == 0){
				Index act = this->getPrev(row_ind, col_ind);
				if(act.getIsValid()){
					this->solveSudoku(act.getRowInd(), act.getColInd());
				}else{
					return false;
				}
			}else{
				this->setSolutionMatrix(row_ind, col_ind, act_sol);
				Index act = this->getNext(row_ind, col_ind);
				//std::cout << "row: " << act.getRowInd() << " col: " << act.getColInd() << " val: " << act.getIsValid() <<std::endl;
				if(act.getIsValid()){
					this->solveSudoku(act.getRowInd(), act.getColInd());
				}else{
					return true;
				}
			}
		}

	}

};


//Intialize the solveing and invites solveSudoku:
std::vector<std::vector<unsigned int>> initSolveSudoku(Sudoku sudoku){

	//Check if the sudoku can be solved:
	if(!sudoku.isValid()){
		//if can't be solved return it:
		return sudoku.getMatrix();
	}

	//Initialize the result matrix's elements to 1:
	sudoku.initializeSolutionMatrix(sudoku.getSize());

	//Initialize indexes:
	int row_ind = 0;
	int col_ind = 0;

	if(sudoku.solveSudoku(row_ind, col_ind)){
		return sudoku.getSolutionMatrix();
	}else{
		return sudoku.getMatrix();
	}
}

//Reads a sudoku from file
Sudoku readSudoku(std::ifstream& input){
	unsigned int n; //size
	input >> n;
	std::vector<std::vector<unsigned int>> matrix(n);
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			unsigned int actual;
			input >> actual;
			matrix[i].push_back(actual);
		}
	}
	return Sudoku(n, matrix);
}

//Writes a sudoku to a file:
void writeSudoku(std::ofstream& output, const std::vector<std::vector<unsigned int>>& matrix){
	for(int i = 0; i < matrix.size(); ++i){
		for(int j = 0; j < matrix[i].size(); ++j){
			output << matrix[i][j] << " ";
		}
		output << "\n";
	}
}

int main()
{
	std::ifstream input("input.txt");

	//Read the number of sudokus:
	unsigned int sudoku_count;
	input >> sudoku_count;

	// Read all the data into Sudokus and strat to solve them
	std::vector<std::future<std::vector<std::vector<unsigned int>>>> results;
	Sudoku actual;

	for(int i = 0; i < sudoku_count; ++i){
		actual = readSudoku(input);
		results.push_back(std::async(std::launch::async, initSolveSudoku, actual));
		//initSolveSudoku(actual);
	}

	input.close();

	// Wait for the function to return, write the result into a file
	std::ofstream output("output.txt");

	for (std::future<std::vector<std::vector<unsigned int>>>& f : results){
		f.wait();
		writeSudoku(output, f.get());
	}
	output.close();

	return 0;
}
